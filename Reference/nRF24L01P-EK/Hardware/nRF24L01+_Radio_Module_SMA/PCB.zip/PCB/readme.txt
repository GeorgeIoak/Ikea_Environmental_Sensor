This PCB is exactly the same as the PCB for the "nRF24L01 Radio Module SMA."
